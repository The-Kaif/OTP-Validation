// Import Component
import Register from "./Components/Register";
function App() {
  return (
    <div>
      <Register />
    </div>
  );
}

export default App;
